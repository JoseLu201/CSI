#pragma once

int fact(int n);
